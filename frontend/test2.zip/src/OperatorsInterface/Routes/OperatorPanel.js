import React from "react";
import "./Styling/Navbar.css";
//import OperatorNavbar from "./OperatorNavbar";

function OperatorPanel() {
  return <div className="main">operators&apos; panel</div>;
}

export default OperatorPanel;
