import React from "react";
import "./Styling/Navbar.css";
import Login_API from "../Components/Login_API/Login_API";

function Login() {
  return (
    <div className="main">
      <Login_API />
    </div>
  );
}

export default Login;
