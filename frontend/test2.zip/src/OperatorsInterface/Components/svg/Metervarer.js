import React from "react";
<svg
  width="65.85mm"
  height="65.943mm"
  version="1.1"
  viewBox="0 0 65.85 65.943"
  xmlns="http://www.w3.org/2000/svg"
>
  <g
    transform="translate(-37.193 -45.076)"
    fillRule="evenodd"
    strokeOpacity="0"
  >
    <path
      d="m102.16 78.048a32.093 32.093 0 0 1-31.953 32.092 32.093 32.093 0 0 1-32.232-31.812 32.093 32.093 0 0 1 31.671-32.37 32.093 32.093 0 0 1 32.508 31.53"
      fill="#b3b3b3"
    />
    <path
      d="m81.371 78.333a11.394 11.394 0 0 1-11.344 11.394 11.394 11.394 0 0 1-11.443-11.294 11.394 11.394 0 0 1 11.244-11.492 11.394 11.394 0 0 1 11.541 11.194"
      fill="#f2f2f2"
    />
  </g>
</svg>;

const Metervarer = () => {
  return (
    <div>
      <svg
        width="16.804mm"
        height="16.924mm"
        version="1.1"
        viewBox="0 0 65.85 65.943"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g
          transform="translate(-37.193 -45.076)"
          fillRule="evenodd"
          strokeOpacity="0"
        >
          <path
            d="m102.16 78.048a32.093 32.093 0 0 1-31.953 32.092 32.093 32.093 0 0 1-32.232-31.812 32.093 32.093 0 0 1 31.671-32.37 32.093 32.093 0 0 1 32.508 31.53"
            fill="#b3b3b3"
          />
          <path
            d="m81.371 78.333a11.394 11.394 0 0 1-11.344 11.394 11.394 11.394 0 0 1-11.443-11.294 11.394 11.394 0 0 1 11.244-11.492 11.394 11.394 0 0 1 11.541 11.194"
            fill="#f2f2f2"
          />
        </g>
      </svg>
    </div>
  );
};

export default Metervarer;
