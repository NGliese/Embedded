import React from "react";
import AdminNavbar from "./AdminNavbar";
import "./Styling/Navbar.css";

function Waste() {
  return (
    <div className="main">
      <AdminNavbar />
    </div>
  );
}

export default Waste;
