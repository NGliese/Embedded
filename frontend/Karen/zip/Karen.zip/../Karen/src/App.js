
import './App.css';

import {BrowserRouter as Router, Route} from 'react-router-dom'
import DogFeeder from './routing/DogFeeder';
import Home from './routing/Home';
//<Route path='/' component={Home} />
function App() {
  return (
    <h1>Hello world!</h1>
  );
}

export default App;
